import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Movie } from '../types';

interface MovieFormProps {
  onAddMovie: (movie: Omit<Movie, 'id' | 'addedAt' | 'updatedAt'>) => void;
}

export function MovieForm({ onAddMovie }: MovieFormProps) {
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState<Movie['status']>('planned');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAddMovie({
      title,
      status,
      notes: '',
    });

    setTitle('');
    setStatus('planned');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl overflow-hidden">
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold text-gray-900">Add New Movie</h2>
          <div className="h-10 w-10 bg-indigo-100 rounded-full flex items-center justify-center">
            <Plus className="h-6 w-6 text-indigo-600" />
          </div>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
              Movie Title
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
              placeholder="Enter movie title"
            />
          </div>
          <div>
            <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-2">
              Status
            </label>
            <select
              id="status"
              value={status}
              onChange={(e) => setStatus(e.target.value as Movie['status'])}
              className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
            >
              <option value="planned">Plan to Watch</option>
              <option value="watching">Watching</option>
              <option value="completed">Completed</option>
            </select>
          </div>
        </div>
      </div>
      <div className="px-6 py-4 bg-gray-50">
        <button
          type="submit"
          className="w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add to Watchlist
        </button>
      </div>
    </form>
  );
}