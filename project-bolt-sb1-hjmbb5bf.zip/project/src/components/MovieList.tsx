import React from 'react';
import { Check, Clock, Play, Trash2 } from 'lucide-react';
import { Movie } from '../types';

interface MovieListProps {
  movies: Movie[];
  onUpdateStatus: (id: string, status: Movie['status']) => void;
  onDeleteMovie: (id: string) => void;
}

export function MovieList({ movies, onUpdateStatus, onDeleteMovie }: MovieListProps) {
  const getStatusIcon = (status: Movie['status']) => {
    switch (status) {
      case 'completed':
        return <Check className="h-5 w-5 text-green-500" />;
      case 'watching':
        return <Play className="h-5 w-5 text-blue-500" />;
      case 'planned':
        return <Clock className="h-5 w-5 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: Movie['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-50 border-green-200';
      case 'watching':
        return 'bg-blue-50 border-blue-200';
      case 'planned':
        return 'bg-yellow-50 border-yellow-200';
    }
  };

  const getStatusText = (status: Movie['status']) => {
    switch (status) {
      case 'completed':
        return 'Completed';
      case 'watching':
        return 'Currently Watching';
      case 'planned':
        return 'Plan to Watch';
    }
  };

  if (movies.length === 0) {
    return (
      <div className="text-center py-12">
        <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No movies yet</h3>
        <p className="text-gray-500">Start by adding some movies to your watchlist</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {movies.map((movie) => (
        <div
          key={movie.id}
          className={`p-4 rounded-xl border-2 transition-all hover:shadow-md ${getStatusColor(
            movie.status
          )}`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="h-10 w-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                {getStatusIcon(movie.status)}
              </div>
              <div>
                <h3 className="text-lg font-medium text-gray-900">{movie.title}</h3>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-500">
                    {getStatusText(movie.status)}
                  </span>
                  <span className="text-gray-300">•</span>
                  <span className="text-sm text-gray-500">
                    Added {new Date(movie.addedAt).toLocaleDateString()}
                  </span>
                </div>
                {movie.notes && (
                  <p className="text-sm text-gray-600 mt-1">{movie.notes}</p>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <select
                value={movie.status}
                onChange={(e) => onUpdateStatus(movie.id, e.target.value as Movie['status'])}
                className="px-3 py-2 rounded-lg border border-gray-300 bg-white text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
              >
                <option value="planned">Plan to Watch</option>
                <option value="watching">Watching</option>
                <option value="completed">Completed</option>
              </select>
              <button
                onClick={() => onDeleteMovie(movie.id)}
                className="p-2 text-gray-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                title="Delete movie"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}