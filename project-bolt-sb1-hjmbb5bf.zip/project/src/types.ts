export interface Movie {
  id: string;
  title: string;
  status: 'watching' | 'completed' | 'planned';
  rating?: number;
  notes?: string;
  addedAt: string;
  updatedAt: string;
}