import React from 'react';
import { Film } from 'lucide-react';
import { MovieForm } from './components/MovieForm';
import { MovieList } from './components/MovieList';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Movie } from './types';

const initialMovies: Omit<Movie, 'id' | 'addedAt' | 'updatedAt'>[] = [
  {
    title: "Inception",
    status: "completed",
    notes: "Mind-bending thriller about dreams within dreams"
  },
  {
    title: "The Shawshank Redemption",
    status: "watching",
    notes: "Classic prison drama"
  },
  {
    title: "Oppenheimer",
    status: "planned",
    notes: "Biographical thriller about J. Robert Oppenheimer"
  },
  {
    title: "Pulp Fiction",
    status: "completed",
    notes: "Quentin Tarantino's masterpiece"
  },
  {
    title: "The Dark Knight",
    status: "watching",
    notes: "Christopher Nolan's Batman epic"
  }
];

function App() {
  const [movies, setMovies] = useLocalStorage<Movie[]>('movies', initialMovies.map(movie => ({
    ...movie,
    id: crypto.randomUUID(),
    addedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  })));

  const handleAddMovie = (movieData: Omit<Movie, 'id' | 'addedAt' | 'updatedAt'>) => {
    const newMovie: Movie = {
      ...movieData,
      id: crypto.randomUUID(),
      addedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setMovies((prev) => [...prev, newMovie]);
  };

  const handleUpdateStatus = (id: string, status: Movie['status']) => {
    setMovies((prev) =>
      prev.map((movie) =>
        movie.id === id
          ? { ...movie, status, updatedAt: new Date().toISOString() }
          : movie
      )
    );
  };

  const handleDeleteMovie = (id: string) => {
    setMovies((prev) => prev.filter((movie) => movie.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="bg-white p-4 rounded-full w-20 h-20 mx-auto shadow-lg flex items-center justify-center mb-6">
            <Film className="h-12 w-12 text-indigo-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-3">Movie Watchlist</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Keep track of your movie journey - from what you plan to watch to what you've completed
          </p>
        </div>

        <div className="grid gap-8">
          <MovieForm onAddMovie={handleAddMovie} />
          <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 shadow-xl">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Your Movies</h2>
            <MovieList
              movies={movies}
              onUpdateStatus={handleUpdateStatus}
              onDeleteMovie={handleDeleteMovie}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;